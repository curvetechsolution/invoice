# Invoice Pro - Professional Invoice Management System

## Overview

Invoice Pro is a comprehensive web-based invoice management application designed for small to medium businesses. The system provides a complete solution for creating, managing, and exporting professional invoices with multi-currency support, client management, and PDF export capabilities. Built with a modern tech stack focusing on performance and user experience, the application follows Material Design principles to deliver a clean, professional interface optimized for data-heavy workflows.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development patterns
- **Routing**: Wouter for lightweight client-side routing
- **UI Framework**: Shadcn/ui components built on Radix UI primitives with Tailwind CSS
- **State Management**: TanStack Query for server state management and React Context for authentication
- **Styling**: Tailwind CSS with custom design system following Material Design principles
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Server**: Express.js with TypeScript for API endpoints
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Authentication**: Session-based authentication with bcrypt for password hashing
- **Storage**: In-memory storage implementation with interface for future database integration
- **API Design**: RESTful endpoints with proper error handling and validation

### Design System
- **Color Palette**: Professional blue theme with semantic color variations for different states
- **Typography**: Inter font family optimized for data-heavy interfaces
- **Component Library**: Consistent form controls, data tables, and interactive elements
- **Responsive Design**: Mobile-first approach with proper breakpoints for all device sizes

### Database Schema
- **Users**: Authentication and company profile information
- **Invoices**: Invoice metadata with auto-generated numbers and currency support
- **Clients**: Customer information with contact details
- **Invoice Items**: Line items with flexible discount options (percentage or fixed amount)
- **Relationships**: Proper foreign key relationships between entities

### Authentication Flow
- **Registration**: User signup with company profile setup
- **Login**: Session-based authentication with persistent storage
- **Profile Management**: Company details and logo upload functionality
- **Security**: Password hashing and session management

### Core Features
- **Invoice Creation**: Dynamic line item management with real-time calculations
- **Client Management**: Customer database with auto-fill capabilities
- **Multi-Currency**: Support for PKR, USD, EUR, and GBP with proper formatting
- **Payment Tracking**: Deposit management and payment status tracking
- **Export Options**: PDF generation and deployment package creation

## External Dependencies

### UI and Component Libraries
- **Radix UI**: Accessible component primitives for complex UI elements
- **Tailwind CSS**: Utility-first CSS framework for consistent styling
- **Lucide React**: Modern icon library for consistent iconography
- **Class Variance Authority**: Type-safe component variant management

### Database and ORM
- **Neon Database**: Serverless PostgreSQL database for production deployment
- **Drizzle ORM**: Type-safe database toolkit with migration support
- **Drizzle Kit**: Database introspection and migration management

### Authentication and Security
- **bcrypt**: Password hashing for secure user authentication
- **connect-pg-simple**: PostgreSQL session store for Express sessions

### Development and Build Tools
- **Vite**: Fast build tool with hot module replacement
- **ESBuild**: JavaScript bundler for production builds
- **TypeScript**: Static type checking for enhanced development experience
- **PostCSS**: CSS processing with Tailwind CSS integration

### Data Management
- **TanStack Query**: Server state management with caching and synchronization
- **React Hook Form**: Form validation and state management
- **Zod**: Runtime type validation and schema parsing
- **date-fns**: Date manipulation and formatting utilities

### Third-party Integrations
- **Google Fonts**: Inter font family for professional typography
- **PayPal**: Payment processing integration (configurable)
- **File Upload**: Logo and document upload capabilities
- **PDF Generation**: Invoice export functionality (planned)