import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import bcrypt from "bcrypt";
import { insertUserSchema } from "@shared/schema";
import { z } from "zod";

const SALT_ROUNDS = 12;

// Authentication validation schemas
const signInSchema = z.object({
  email: z.string().email("Invalid email format"),
  password: z.string().min(1, "Password is required")
});

const signUpSchema = insertUserSchema.extend({
  password: z.string().min(8, "Password must be at least 8 characters long")
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication endpoints
  
  // Sign up endpoint
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const validation = signUpSchema.safeParse(req.body);
      
      if (!validation.success) {
        await storage.logAuthAttempt(req.body.email || 'unknown', false, 'signup', {
          error: 'Validation failed',
          errors: validation.error.errors,
          ip: req.ip,
          userAgent: req.get('User-Agent')
        });
        
        return res.status(400).json({
          error: "Validation failed",
          details: validation.error.errors
        });
      }

      const { email, password, firstName, lastName, companyName, companyAddress, companyPhone, companyEmail, logoUrl, isSetupComplete } = validation.data;

      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        await storage.logAuthAttempt(email, false, 'signup', {
          error: 'Email already exists',
          ip: req.ip,
          userAgent: req.get('User-Agent')
        });
        
        return res.status(400).json({
          error: "Email already exists"
        });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

      // Create user
      const user = await storage.createUser({
        email,
        password: hashedPassword,
        firstName,
        lastName,
        companyName,
        companyAddress,
        companyPhone,
        companyEmail,
        logoUrl,
        isSetupComplete: isSetupComplete || false
      });

      // Log successful signup (without password)
      await storage.logAuthAttempt(email, true, 'signup', {
        userId: user.id,
        firstName,
        lastName,
        companyName,
        ip: req.ip,
        userAgent: req.get('User-Agent')
      });

      // Return user without password
      const { password: _, ...userWithoutPassword } = user;
      
      res.status(201).json({
        message: "User created successfully",
        user: userWithoutPassword
      });
      
    } catch (error) {
      console.error('Signup error:', error);
      
      await storage.logAuthAttempt(req.body.email || 'unknown', false, 'signup', {
        error: 'Server error',
        message: error instanceof Error ? error.message : 'Unknown error',
        ip: req.ip,
        userAgent: req.get('User-Agent')
      });
      
      res.status(500).json({
        error: "Internal server error"
      });
    }
  });

  // Sign in endpoint
  app.post("/api/auth/signin", async (req, res) => {
    try {
      const validation = signInSchema.safeParse(req.body);
      
      if (!validation.success) {
        await storage.logAuthAttempt(req.body.email || 'unknown', false, 'signin', {
          error: 'Validation failed',
          errors: validation.error.errors,
          ip: req.ip,
          userAgent: req.get('User-Agent')
        });
        
        return res.status(400).json({
          error: "Invalid email or password"
        });
      }

      const { email, password } = validation.data;

      // Find user
      const user = await storage.getUserByEmail(email);
      if (!user) {
        await storage.logAuthAttempt(email, false, 'signin', {
          error: 'User not found',
          ip: req.ip,
          userAgent: req.get('User-Agent')
        });
        
        return res.status(401).json({
          error: "Invalid email or password"
        });
      }

      // Verify password
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        await storage.logAuthAttempt(email, false, 'signin', {
          error: 'Invalid password',
          userId: user.id,
          ip: req.ip,
          userAgent: req.get('User-Agent')
        });
        
        return res.status(401).json({
          error: "Invalid email or password"
        });
      }

      // Log successful signin
      await storage.logAuthAttempt(email, true, 'signin', {
        userId: user.id,
        firstName: user.firstName,
        lastName: user.lastName,
        ip: req.ip,
        userAgent: req.get('User-Agent')
      });

      // Return user without password
      const { password: _, ...userWithoutPassword } = user;
      
      res.json({
        message: "Sign in successful",
        user: userWithoutPassword
      });
      
    } catch (error) {
      console.error('Signin error:', error);
      
      await storage.logAuthAttempt(req.body.email || 'unknown', false, 'signin', {
        error: 'Server error',
        message: error instanceof Error ? error.message : 'Unknown error',
        ip: req.ip,
        userAgent: req.get('User-Agent')
      });
      
      res.status(500).json({
        error: "Internal server error"
      });
    }
  });

  // Admin endpoint to view authentication logs
  app.get("/api/admin/auth-logs", async (req, res) => {
    try {
      const logs = await storage.getAuthLogs();
      res.json({
        logs,
        total: logs.length
      });
    } catch (error) {
      console.error('Error fetching auth logs:', error);
      res.status(500).json({
        error: "Failed to fetch authentication logs"
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
