import { type Invoice, type InsertInvoice, type Client, type InsertClient, type InvoiceItem, type InsertInvoiceItem, type Currency, type DiscountType, type User, type InsertUser } from "@shared/schema";
import { randomUUID } from "crypto";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // Invoice methods
  getInvoice(id: string): Promise<Invoice | undefined>;
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  updateInvoice(id: string, invoice: Partial<Invoice>): Promise<Invoice | undefined>;
  deleteInvoice(id: string): Promise<boolean>;
  
  // Client methods
  getClient(id: string): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;
  getAllClients(): Promise<Client[]>;
  
  // Invoice item methods
  getInvoiceItems(invoiceId: string): Promise<InvoiceItem[]>;
  createInvoiceItem(item: InsertInvoiceItem): Promise<InvoiceItem>;
  updateInvoiceItem(id: string, item: Partial<InvoiceItem>): Promise<InvoiceItem | undefined>;
  deleteInvoiceItem(id: string): Promise<boolean>;
  
  // User authentication methods
  createUser(user: InsertUser): Promise<User>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserById(id: string): Promise<User | undefined>;
  updateUser(id: string, user: Partial<User>): Promise<User | undefined>;
  
  // Admin logging methods
  logAuthAttempt(email: string, success: boolean, action: 'signin' | 'signup', metadata?: any): Promise<void>;
  getAuthLogs(): Promise<any[]>;
}

export class MemStorage implements IStorage {
  private invoices: Map<string, Invoice>;
  private clients: Map<string, Client>;
  private invoiceItems: Map<string, InvoiceItem>;
  private users: Map<string, User>;
  private authLogs: Array<{
    id: string;
    email: string;
    success: boolean;
    action: 'signin' | 'signup';
    timestamp: Date;
    metadata?: any;
  }>;

  constructor() {
    this.invoices = new Map();
    this.clients = new Map();
    this.invoiceItems = new Map();
    this.users = new Map();
    this.authLogs = [];
  }

  // Invoice methods
  async getInvoice(id: string): Promise<Invoice | undefined> {
    return this.invoices.get(id);
  }

  async createInvoice(insertInvoice: InsertInvoice): Promise<Invoice> {
    const id = randomUUID();
    const invoiceNumber = `INV-${Date.now().toString().slice(-6)}`;
    const invoice: Invoice = { 
      ...insertInvoice, 
      id, 
      invoiceNumber,
      currency: (insertInvoice.currency || 'USD') as Currency,
      companyName: insertInvoice.companyName || null,
      companyAddress: insertInvoice.companyAddress || null,
      companyPhone: insertInvoice.companyPhone || null,
      companyEmail: insertInvoice.companyEmail || null,
      logoUrl: insertInvoice.logoUrl || null,
      depositPercentage: insertInvoice.depositPercentage || "0",
      isPaid: insertInvoice.isPaid || false,
      notes: insertInvoice.notes || null,
      clientId: insertInvoice.clientId || null
    };
    this.invoices.set(id, invoice);
    return invoice;
  }

  async updateInvoice(id: string, invoiceData: Partial<Invoice>): Promise<Invoice | undefined> {
    const invoice = this.invoices.get(id);
    if (!invoice) return undefined;
    const updated = { ...invoice, ...invoiceData };
    this.invoices.set(id, updated);
    return updated;
  }

  async deleteInvoice(id: string): Promise<boolean> {
    return this.invoices.delete(id);
  }

  // Client methods
  async getClient(id: string): Promise<Client | undefined> {
    return this.clients.get(id);
  }

  async createClient(insertClient: InsertClient): Promise<Client> {
    const id = randomUUID();
    const client: Client = { 
      ...insertClient, 
      id,
      phone: insertClient.phone || null,
      email: insertClient.email || null,
      address: insertClient.address || null
    };
    this.clients.set(id, client);
    return client;
  }

  async getAllClients(): Promise<Client[]> {
    return Array.from(this.clients.values());
  }

  // Invoice item methods
  async getInvoiceItems(invoiceId: string): Promise<InvoiceItem[]> {
    return Array.from(this.invoiceItems.values()).filter(
      item => item.invoiceId === invoiceId
    );
  }

  async createInvoiceItem(insertItem: InsertInvoiceItem): Promise<InvoiceItem> {
    const id = randomUUID();
    const item: InvoiceItem = { 
      ...insertItem, 
      id,
      description: insertItem.description || null,
      discountType: (insertItem.discountType || "percentage") as DiscountType,
      discountValue: insertItem.discountValue || "0",
      invoiceId: insertItem.invoiceId || null
    };
    this.invoiceItems.set(id, item);
    return item;
  }

  async updateInvoiceItem(id: string, itemData: Partial<InvoiceItem>): Promise<InvoiceItem | undefined> {
    const item = this.invoiceItems.get(id);
    if (!item) return undefined;
    const updated = { ...item, ...itemData };
    this.invoiceItems.set(id, updated);
    return updated;
  }

  async deleteInvoiceItem(id: string): Promise<boolean> {
    return this.invoiceItems.delete(id);
  }

  // User authentication methods
  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      companyName: insertUser.companyName || null,
      companyAddress: insertUser.companyAddress || null,
      companyPhone: insertUser.companyPhone || null,
      companyEmail: insertUser.companyEmail || null,
      logoUrl: insertUser.logoUrl || null,
      isSetupComplete: insertUser.isSetupComplete || false,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async getUserById(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async updateUser(id: string, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const updated = { ...user, ...userData };
    this.users.set(id, updated);
    return updated;
  }

  // Admin logging methods
  async logAuthAttempt(email: string, success: boolean, action: 'signin' | 'signup', metadata?: any): Promise<void> {
    const logEntry = {
      id: randomUUID(),
      email,
      success,
      action,
      timestamp: new Date(),
      metadata
    };
    this.authLogs.push(logEntry);
    
    // Keep only last 1000 logs to prevent memory issues
    if (this.authLogs.length > 1000) {
      this.authLogs = this.authLogs.slice(-1000);
    }
    
    console.log(`[AUTH LOG] ${action.toUpperCase()} attempt for ${email}: ${success ? 'SUCCESS' : 'FAILED'} at ${logEntry.timestamp.toISOString()}`);
  }

  async getAuthLogs(): Promise<any[]> {
    return [...this.authLogs].reverse(); // Return newest first
  }
}

export const storage = new MemStorage();
