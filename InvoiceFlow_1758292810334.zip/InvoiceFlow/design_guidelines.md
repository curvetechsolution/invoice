# Invoice Software Web App Design Guidelines

## Design Approach
**System-Based Approach**: Using Material Design principles for a professional, utility-focused invoice application that prioritizes functionality and data clarity.

## Core Design Elements

### Color Palette
- **Primary Blue**: 220 85% 45% (professional blue for headers and primary actions)
- **Light Blue Background**: 220 30% 95% (subtle background tint)
- **Dark Mode Primary**: 220 70% 60% (adjusted for dark theme)
- **Success Green**: 142 76% 36% (for positive values, completed invoices)
- **Warning Orange**: 25 95% 53% (for pending payments, alerts)
- **Neutral Grays**: 220 14% 96%, 220 13% 69%, 220 9% 46% (backgrounds, borders, text)

### Typography
- **Primary Font**: Inter (Google Fonts) for excellent readability in data-heavy interfaces
- **Font Scale**: text-sm for labels, text-base for body, text-lg for headers, text-2xl for totals
- **Font Weights**: font-normal (400), font-medium (500), font-semibold (600)

### Layout System
- **Spacing Units**: Consistent use of Tailwind units 2, 4, 6, 8, and 12 (p-4, m-6, gap-8)
- **Grid System**: 12-column responsive grid with proper breakpoints
- **Container**: max-width with centered alignment and horizontal padding

### Component Library

#### Headers & Navigation
- Clean top navigation with logo placement and primary actions
- Section headers with blue accent bars (h-1 w-12 bg-blue-500)
- Breadcrumb navigation for multi-step processes

#### Forms & Input Fields
- Consistent form styling with proper labels and validation states
- Multi-currency selector with flag icons from icon library
- Date pickers with calendar integration
- File upload areas with drag-and-drop styling

#### Data Display
- Clean table layouts for invoice line items
- Card-based client information displays
- Summary boxes for totals with emphasized styling
- Progress indicators for invoice status

#### Interactive Elements
- Primary blue buttons for main actions (Create, Save, Export)
- Secondary gray buttons for supporting actions
- Icon buttons for add/remove line items
- Toggle switches for discount type selection

#### Invoice Layout
- Professional invoice template with company header section
- Transparent light blue backgrounds (bg-blue-50/50) for section separation
- Clear typography hierarchy for invoice data
- Proper alignment for numerical values (right-aligned)

### Responsive Design
- Mobile-first approach with collapsible sections
- Touch-friendly button sizes (min-height: 44px)
- Horizontal scroll for wide tables on mobile
- Stacked layout for invoice sections on smaller screens

### Visual Hierarchy
- Use of whitespace and subtle shadows (shadow-sm, shadow-md)
- Color coding for different invoice states
- Progressive disclosure for advanced features
- Clear visual separation between functional areas

### Performance Considerations
- Minimal animations (subtle hover states only)
- Efficient component rendering for dynamic invoice rows
- Optimized for Replit's resource constraints
- Clean, semantic HTML structure

This design system ensures a professional, trustworthy appearance suitable for business invoice management while maintaining excellent usability and performance optimization.