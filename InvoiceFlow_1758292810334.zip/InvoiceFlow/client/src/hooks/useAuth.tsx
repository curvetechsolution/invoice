import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  companyName?: string;
  companyAddress?: string;
  companyPhone?: string;
  companyEmail?: string;
  logoUrl?: string;
  isSetupComplete: boolean;
}

interface AuthContextType {
  user: User | null;
  login: (user: User) => void;
  logout: () => void;
  updateUser: (userData: Partial<User>) => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    // Check for saved user session in localStorage
    const savedUser = localStorage.getItem('invoice-user');
    if (savedUser) {
      try {
        const userData = JSON.parse(savedUser);
        setUser(userData);
        // Note: In a production app, you'd want to validate this session with the backend
        // For now, we trust localStorage since we don't have persistent sessions yet
      } catch (error) {
        console.error('Error parsing saved user:', error);
        localStorage.removeItem('invoice-user');
      }
    }
  }, []);

  const login = (userData: User) => {
    setUser(userData);
    localStorage.setItem('invoice-user', JSON.stringify(userData));
    // Only log non-sensitive information
    console.log('User authenticated successfully:', userData.email);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('invoice-user');
    console.log('User session ended');
  };

  const updateUser = (userData: Partial<User>) => {
    if (!user) return;
    
    const updatedUser = { ...user, ...userData };
    setUser(updatedUser);
    localStorage.setItem('invoice-user', JSON.stringify(updatedUser));
    console.log('User profile updated for:', updatedUser.email);
  };

  const value = {
    user,
    login,
    logout,
    updateUser,
    isAuthenticated: !!user
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}