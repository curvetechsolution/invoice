import InvoiceForm from "@/components/InvoiceForm";

export default function Invoice() {
  return <InvoiceForm />;
}