import { useState } from "react";
import { Trash2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import type { InvoiceItem, DiscountType, Currency } from "@shared/schema";

interface InvoiceItemRowProps {
  item: InvoiceItem;
  currency: Currency;
  taxPercentage?: number;
  onUpdate: (id: string, field: keyof InvoiceItem, value: string | number) => void;
  onDelete: (id: string) => void;
  onTaxChange?: (taxPercentage: number) => void;
}

const currencySymbols: Record<Currency, string> = {
  PKR: "₨",
  USD: "$",
  EUR: "€",
  GBP: "£"
};

export default function InvoiceItemRow({ 
  item, 
  currency, 
  taxPercentage = 0,
  onUpdate, 
  onDelete,
  onTaxChange 
}: InvoiceItemRowProps) {
  const unitPrice = parseFloat(item.unitPrice) || 0;
  const quantity = item.quantity || 0;
  const discountValue = parseFloat(item.discountValue) || 0;
  
  // Calculate discount amount
  const discountAmount = item.discountType === 'percentage' 
    ? (unitPrice * quantity * discountValue / 100)
    : discountValue;
    
  const subtotalBeforeTax = (unitPrice * quantity) - discountAmount;
  const taxAmount = (subtotalBeforeTax * taxPercentage) / 100;
  const subtotal = subtotalBeforeTax + taxAmount;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-12 gap-4 items-start p-4 border rounded-lg bg-card">
        {/* Project Title */}
        <div className="col-span-12 md:col-span-3">
          <Input
            placeholder="Project Title"
            value={item.title}
            onChange={(e) => onUpdate(item.id, 'title', e.target.value)}
            data-testid={`input-item-title-${item.id}`}
          />
        </div>
        
        {/* Description */}
        <div className="col-span-12 md:col-span-3">
          <Textarea
            placeholder="Project Description"
            value={item.description || ''}
            onChange={(e) => onUpdate(item.id, 'description', e.target.value)}
            className="min-h-[40px] resize-none"
            data-testid={`input-item-description-${item.id}`}
          />
        </div>
        
        {/* Unit Price */}
        <div className="col-span-6 md:col-span-2">
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
              {currencySymbols[currency]}
            </span>
            <Input
              type="number"
              placeholder="0"
              value={item.unitPrice}
              onChange={(e) => onUpdate(item.id, 'unitPrice', e.target.value)}
              className="pl-8"
              data-testid={`input-item-price-${item.id}`}
            />
          </div>
        </div>
        
        {/* Quantity - Optional field */}
        <div className="col-span-6 md:col-span-1">
          <Input
            type="number"
            placeholder="1"
            min="1"
            value={item.quantity || 1}
            onChange={(e) => onUpdate(item.id, 'quantity', parseInt(e.target.value) || 1)}
            data-testid={`input-item-quantity-${item.id}`}
          />
        </div>
        
        {/* Discount */}
        <div className="col-span-8 md:col-span-2 space-y-2">
          <Select value={item.discountType} onValueChange={(val) => onUpdate(item.id, 'discountType', val)}>
            <SelectTrigger data-testid={`select-discount-type-${item.id}`}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="percentage">Percentage (%)</SelectItem>
              <SelectItem value="fixed">Fixed Amount</SelectItem>
            </SelectContent>
          </Select>
          <div className="relative">
            {item.discountType === 'fixed' && (
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                {currencySymbols[currency]}
              </span>
            )}
            <Input
              type="number"
              placeholder="0"
              value={item.discountValue}
              onChange={(e) => onUpdate(item.id, 'discountValue', e.target.value)}
              className={item.discountType === 'fixed' ? 'pl-8' : ''}
              data-testid={`input-item-discount-${item.id}`}
            />
            {item.discountType === 'percentage' && (
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                %
              </span>
            )}
          </div>
        </div>
        
        {/* Subtotal & Delete */}
        <div className="col-span-4 md:col-span-1 flex items-center justify-between">
          <div className="text-right">
            <div className="text-sm font-semibold" data-testid={`text-item-subtotal-${item.id}`}>
              {currencySymbols[currency]}{Math.round(subtotal)}
            </div>
            {taxPercentage > 0 && (
              <div className="text-xs text-muted-foreground">
                +{taxPercentage}% tax
              </div>
            )}
          </div>
          <Button
            size="icon"
            variant="ghost"
            onClick={() => onDelete(item.id)}
            className="text-destructive hover:text-destructive hover:bg-destructive/10"
            data-testid={`button-delete-item-${item.id}`}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      {/* Optional Tax Field - only show for first item */}
      {onTaxChange && (
        <div className="bg-muted/20 p-3 rounded-lg border border-muted/30">
          <div className="flex items-center gap-4">
            <Label htmlFor={`tax-percentage-${item.id}`} className="text-sm font-medium">
              Optional Tax (applies to all items):
            </Label>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Input
                  id={`tax-percentage-${item.id}`}
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={taxPercentage}
                  onChange={(e) => onTaxChange(parseFloat(e.target.value) || 0)}
                  className="w-20 pr-6"
                  placeholder="0"
                  data-testid="input-tax-percentage"
                />
                <span className="absolute right-2 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">%</span>
              </div>
              <span className="text-sm text-muted-foreground">
                (Leave blank if no tax)
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}