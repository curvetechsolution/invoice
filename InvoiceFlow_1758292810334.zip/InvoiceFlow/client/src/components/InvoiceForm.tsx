import { useState, useCallback } from "react";
import { Plus, LogOut, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import InvoiceHeader from "./InvoiceHeader";
import InvoiceItemRow from "./InvoiceItemRow";
import ClientSection from "./ClientSection";
import InvoiceTotal from "./InvoiceTotal";
import BankAccountInfo from "./BankAccountInfo";
import NotesSection from "./NotesSection";
import ExportButtons from "./ExportButtons";
import type { InvoiceItem, Client, Currency } from "@shared/schema";

interface InvoiceFormState {
  // Header fields
  invoiceNumber: string;
  issueDate: string;
  dueDate: string;
  currency: Currency;
  
  // Client
  selectedClient: Client | null;
  
  // Items
  items: InvoiceItem[];
  taxPercentage: number;
  
  // Payment
  depositPercentage: number;
  isPaid: boolean;
  
  // Bank details
  bankDetails: {
    accountName: string;
    bankName: string;
    accountNumber: string;
    routingNumber: string;
    swiftCode: string;
    paypalEmail: string;
    enablePayPal: boolean;
  };
  
  // Notes
  notes: string;
}

export default function InvoiceForm() {
  const { user, logout } = useAuth();
  const [formState, setFormState] = useState<InvoiceFormState>({
    invoiceNumber: `INV-${Date.now().toString().slice(-6)}`,
    issueDate: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    currency: 'USD',
    selectedClient: null,
    items: [],
    taxPercentage: 0,
    depositPercentage: 0,
    isPaid: false,
    bankDetails: {
      accountName: user?.companyName || '',
      bankName: '',
      accountNumber: '',
      routingNumber: '',
      swiftCode: '',
      paypalEmail: user?.companyEmail || '',
      enablePayPal: false
    },
    notes: ''
  });

  const handleFieldChange = useCallback((field: string, value: any) => {
    setFormState(prev => ({ ...prev, [field]: value }));
    console.log(`Invoice ${field} changed:`, value);
  }, []);

  const handleClientSelect = useCallback((client: Client | null) => {
    setFormState(prev => ({ ...prev, selectedClient: client }));
    console.log('Client selected:', client?.name || 'none');
  }, []);

  const addNewItem = useCallback(() => {
    const newItem: InvoiceItem = {
      id: Date.now().toString(),
      invoiceId: null,
      title: '',
      description: null,
      unitPrice: '0.00',
      quantity: 1,
      discountType: 'percentage',
      discountValue: '0.00'
    };
    setFormState(prev => ({
      ...prev,
      items: [...prev.items, newItem]
    }));
    console.log('Added new item');
  }, []);

  const updateItem = useCallback((id: string, field: keyof InvoiceItem, value: string | number) => {
    setFormState(prev => ({
      ...prev,
      items: prev.items.map(item => 
        item.id === id ? { ...item, [field]: value } : item
      )
    }));
    console.log(`Item ${id} ${field} updated:`, value);
  }, []);

  const deleteItem = useCallback((id: string) => {
    setFormState(prev => ({
      ...prev,
      items: prev.items.filter(item => item.id !== id)
    }));
    console.log('Deleted item:', id);
  }, []);

  const handleBankDetailsChange = useCallback((field: string, value: string | boolean) => {
    setFormState(prev => ({
      ...prev,
      bankDetails: { ...prev.bankDetails, [field]: value }
    }));
    console.log(`Bank ${field} changed:`, value);
  }, []);

  const handleTaxChange = useCallback((taxPercentage: number) => {
    setFormState(prev => ({ ...prev, taxPercentage }));
    console.log('Tax percentage changed:', taxPercentage);
  }, []);

  // Calculate totals with tax
  const subtotal = formState.items.reduce((sum, item) => {
    const unitPrice = parseFloat(item.unitPrice) || 0;
    const quantity = item.quantity || 0;
    const discountValue = parseFloat(item.discountValue) || 0;
    
    const discountAmount = item.discountType === 'percentage' 
      ? (unitPrice * quantity * discountValue / 100)
      : discountValue;
      
    return sum + ((unitPrice * quantity) - discountAmount);
  }, 0);

  const taxAmount = (subtotal * formState.taxPercentage) / 100;

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Page Header with User Info */}
        <div className="flex items-center justify-between mb-8">
          <div className="text-center flex-1">
            <h1 className="text-3xl font-bold text-primary mb-2">Invoice Pro</h1>
            <p className="text-muted-foreground">Professional Invoice Management System</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right text-sm">
              <div className="font-medium">Welcome, {user?.firstName}</div>
              <div className="text-muted-foreground">{user?.companyName}</div>
            </div>
            <Button variant="outline" onClick={logout} size="sm" data-testid="button-logout">
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>

        <div className="space-y-8">
          {/* Invoice Header - Using user's company data */}
          <InvoiceHeader
            invoiceNumber={formState.invoiceNumber}
            issueDate={formState.issueDate}
            dueDate={formState.dueDate}
            currency={formState.currency}
            companyName={user?.companyName || 'Your Company Name'}
            companyAddress={user?.companyAddress || '123 Business Street\nSuite 100'}
            companyPhone={user?.companyPhone || '+1 (555) 123-4567'}
            companyEmail={user?.companyEmail || 'info@company.com'}
            logoUrl={user?.logoUrl}
            onFieldChange={handleFieldChange}
          />

          {/* Client Section */}
          <ClientSection
            selectedClientId={formState.selectedClient?.id}
            onClientSelect={handleClientSelect}
          />

          {/* Invoice Items */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-semibold text-lg">Invoice Items</h3>
                <div className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-xs font-medium inline-block mt-1">
                  Project Details & Pricing
                </div>
              </div>
              <Button onClick={addNewItem} data-testid="button-add-item">
                <Plus className="h-4 w-4 mr-2" />
                Add Item
              </Button>
            </div>

            <div className="space-y-4">
              {formState.items.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <p>No items added yet. Click "Add Item" to get started.</p>
                </div>
              ) : (
                formState.items.map((item, index) => (
                  <InvoiceItemRow
                    key={item.id}
                    item={item}
                    currency={formState.currency}
                    taxPercentage={formState.taxPercentage}
                    onUpdate={updateItem}
                    onDelete={deleteItem}
                    onTaxChange={index === 0 ? handleTaxChange : undefined} // Only show tax field on first item
                  />
                ))
              )}
            </div>
          </Card>

          {/* Invoice Total with Tax Support */}
          <InvoiceTotal
            currency={formState.currency}
            subtotal={subtotal}
            taxAmount={taxAmount}
            depositPercentage={formState.depositPercentage}
            isPaid={formState.isPaid}
            onDepositChange={(percentage) => handleFieldChange('depositPercentage', percentage)}
            onPaymentStatusToggle={() => handleFieldChange('isPaid', !formState.isPaid)}
          />

          {/* Bank Account Information */}
          <BankAccountInfo
            bankDetails={formState.bankDetails}
            onBankDetailsChange={handleBankDetailsChange}
          />

          {/* Notes Section */}
          <NotesSection
            notes={formState.notes}
            onNotesChange={(notes) => handleFieldChange('notes', notes)}
          />

          {/* Export Buttons */}
          <ExportButtons
            invoiceData={formState}
            invoiceNumber={formState.invoiceNumber}
          />
        </div>
      </div>
    </div>
  );
}