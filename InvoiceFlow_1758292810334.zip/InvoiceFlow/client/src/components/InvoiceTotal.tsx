import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { CheckCircle2, Clock } from "lucide-react";
import type { Currency } from "@shared/schema";

interface InvoiceTotalProps {
  currency: Currency;
  subtotal: number;
  taxAmount?: number;
  depositPercentage: number;
  isPaid: boolean;
  onDepositChange: (percentage: number) => void;
  onPaymentStatusToggle: () => void;
}

const currencySymbols: Record<Currency, string> = {
  PKR: "₨",
  USD: "$",
  EUR: "€",
  GBP: "£"
};

const formatAmount = (amount: number): string => {
  return Math.round(amount).toString(); // Remove .00 decimals as requested
};

export default function InvoiceTotal({
  currency,
  subtotal,
  taxAmount = 0,
  depositPercentage,
  isPaid,
  onDepositChange,
  onPaymentStatusToggle
}: InvoiceTotalProps) {
  const totalAfterTax = subtotal + taxAmount;
  const depositAmount = (totalAfterTax * depositPercentage) / 100;
  const remainingBalance = totalAfterTax - depositAmount;

  return (
    <Card className="p-6">
      <div className="space-y-6">
        {/* Payment Summary - Updated design */}
        <div className="bg-background border border-border p-4 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-lg">Payment Summary</h3>
            <Badge variant={isPaid ? "default" : "secondary"}>
              {isPaid ? (
                <>
                  <CheckCircle2 className="h-3 w-3 mr-1" />
                  Paid
                </>
              ) : (
                <>
                  <Clock className="h-3 w-3 mr-1" />
                  Pending
                </>
              )}
            </Badge>
          </div>
          
          <div className="space-y-3">
            {/* Subtotal - Normal text */}
            <div className="flex justify-between items-center text-sm">
              <span>Subtotal:</span>
              <span className="font-medium" data-testid="text-subtotal">
                {currencySymbols[currency]}{formatAmount(subtotal)}
              </span>
            </div>
            
            {/* Tax - if applicable */}
            {taxAmount > 0 && (
              <div className="flex justify-between items-center text-sm">
                <span>Tax:</span>
                <span className="font-medium" data-testid="text-tax">
                  {currencySymbols[currency]}{formatAmount(taxAmount)}
                </span>
              </div>
            )}
            
            {/* Deposit - Normal text */}
            {depositPercentage > 0 && (
              <div className="flex justify-between items-center text-sm">
                <span>Deposit ({depositPercentage}%):</span>
                <span className="font-medium" data-testid="text-deposit-amount">
                  {currencySymbols[currency]}{formatAmount(depositAmount)}
                </span>
              </div>
            )}
            
            {/* Grand Total - Normal text */}
            <div className="flex justify-between items-center text-sm border-t pt-3">
              <span className="font-medium">Grand Total:</span>
              <span className="font-semibold" data-testid="text-grand-total">
                {currencySymbols[currency]}{formatAmount(totalAfterTax)}
              </span>
            </div>
            
            {/* Remaining Balance - HIGHLIGHTED IN BLUE as per requirements */}
            {depositPercentage > 0 && (
              <div className="bg-primary text-primary-foreground p-3 rounded-lg mt-3">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-semibold">Remaining Balance:</span>
                  <span className="text-xl font-bold" data-testid="text-remaining-balance">
                    {currencySymbols[currency]}{formatAmount(remainingBalance)}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Deposit Configuration */}
        <div className="space-y-4">
          <div>
            <Label htmlFor="deposit-percentage">Deposit Percentage</Label>
            <div className="flex items-center gap-3 mt-2">
              <div className="relative flex-1">
                <Input
                  id="deposit-percentage"
                  type="number"
                  min="0"
                  max="100"
                  value={depositPercentage}
                  onChange={(e) => onDepositChange(Math.max(0, Math.min(100, parseFloat(e.target.value) || 0)))}
                  placeholder="0"
                  data-testid="input-deposit-percentage"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">%</span>
              </div>
              <div className="text-sm text-muted-foreground">
                = {currencySymbols[currency]}{formatAmount(depositAmount)}
              </div>
            </div>
          </div>
          
          {/* Payment Status Toggle */}
          <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
            <div>
              <Label htmlFor="payment-status" className="text-sm font-medium">
                Mark as Paid
              </Label>
              <p className="text-xs text-muted-foreground">
                Toggle when client completes payment
              </p>
            </div>
            <Switch
              id="payment-status"
              checked={isPaid}
              onCheckedChange={onPaymentStatusToggle}
              data-testid="switch-payment-status"
            />
          </div>
        </div>

        {/* Quick Deposit Buttons */}
        <div>
          <Label className="text-sm font-medium mb-2 block">Quick Deposit Options</Label>
          <div className="flex gap-2">
            {[0, 25, 50, 100].map((percentage) => (
              <Button
                key={percentage}
                size="sm"
                variant={depositPercentage === percentage ? "default" : "outline"}
                onClick={() => onDepositChange(percentage)}
                data-testid={`button-deposit-${percentage}`}
              >
                {percentage}%
              </Button>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
}