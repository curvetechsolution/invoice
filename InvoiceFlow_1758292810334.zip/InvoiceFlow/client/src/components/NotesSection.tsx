import { FileText } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface NotesSectionProps {
  notes: string;
  onNotesChange: (notes: string) => void;
}

export default function NotesSection({ notes, onNotesChange }: NotesSectionProps) {
  const defaultNotes = `Instructions:
• Please review all line items carefully
• Contact us immediately with any questions or concerns
• Keep this invoice for your records
• Payment is due within 30 days of invoice date

Additional Notes:
• Late payments may incur additional charges
• All client information is kept strictly confidential
• Project details remain private between client and service provider`;

  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 mb-4">
        <FileText className="h-5 w-5 text-primary" />
        <h3 className="font-semibold">Notes & Terms</h3>
      </div>
      
      <div className="space-y-4">
        <div>
          <Label htmlFor="invoice-notes">Additional Notes</Label>
          <Textarea
            id="invoice-notes"
            placeholder={defaultNotes}
            value={notes}
            onChange={(e) => onNotesChange(e.target.value)}
            className="min-h-[200px] resize-none"
            data-testid="textarea-notes"
          />
          <p className="text-xs text-muted-foreground mt-1">
            Include terms, conditions, instructions, or privacy policy information
          </p>
        </div>
        
        <div className="bg-muted/30 p-3 rounded-lg mt-4">
          <div className="text-sm">
            <div className="font-medium mb-2">Quick Note Templates:</div>
            <div className="text-xs text-muted-foreground space-y-1">
              <div>• Payment terms and instructions</div>
              <div>• Privacy policy information</div>
              <div>• Project-specific requirements</div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}