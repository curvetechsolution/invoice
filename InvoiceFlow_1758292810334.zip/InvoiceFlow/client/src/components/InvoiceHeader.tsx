import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import LogoUploader from "./LogoUploader";
import CurrencySelector from "./CurrencySelector";
import type { Currency } from "@shared/schema";

interface InvoiceHeaderProps {
  invoiceNumber: string;
  issueDate: string;
  dueDate: string;
  currency: Currency;
  companyName: string;
  companyAddress: string;
  companyPhone: string;
  companyEmail: string;
  logoUrl?: string;
  onFieldChange: (field: string, value: string | File | null) => void;
}

export default function InvoiceHeader({
  invoiceNumber,
  issueDate,
  dueDate,
  currency,
  companyName,
  companyAddress,
  companyPhone,
  companyEmail,
  logoUrl,
  onFieldChange
}: InvoiceHeaderProps) {
  return (
    <div className="space-y-6">
      {/* Logo and Company Info */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <LogoUploader 
          logoUrl={logoUrl}
          onLogoChange={(file) => onFieldChange('logo', file)}
        />
        
        {/* Company Info - Transparent styling below logo */}
        <div className="space-y-4">
          <div className="flex items-center gap-4">
            {logoUrl && (
              <img 
                src={logoUrl} 
                alt="Company Logo" 
                className="h-20 w-20 object-contain rounded-md border bg-white"
              />
            )}
            <div className="flex-1">
              <h2 className="text-xl font-bold text-primary mb-2">
                {companyName || "Your Company Name"}
              </h2>
              {/* Company details with transparent styling */}
              <div className="text-sm text-muted-foreground/80 space-y-1 bg-muted/20 p-3 rounded-lg border border-muted/30">
                {companyAddress && (
                  <div className="whitespace-pre-line" data-testid="text-company-address">
                    {companyAddress}
                  </div>
                )}
                <div className="flex flex-wrap gap-4">
                  {companyPhone && (
                    <div data-testid="text-company-phone">Phone: {companyPhone}</div>
                  )}
                  {companyEmail && (
                    <div data-testid="text-company-email">Email: {companyEmail}</div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Invoice Details */}
      <Card className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold text-primary">INVOICE</h2>
          <div className="text-right">
            <div className="text-sm text-muted-foreground">Invoice Number</div>
            <div className="text-lg font-semibold" data-testid="text-invoice-number">#{invoiceNumber}</div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="issue-date">Issue Date</Label>
            <Input
              id="issue-date"
              type="date"
              value={issueDate}
              onChange={(e) => onFieldChange('issueDate', e.target.value)}
              data-testid="input-issue-date"
            />
          </div>
          <div>
            <Label htmlFor="due-date">Due Date</Label>
            <Input
              id="due-date"
              type="date"
              value={dueDate}
              onChange={(e) => onFieldChange('dueDate', e.target.value)}
              data-testid="input-due-date"
            />
          </div>
          <CurrencySelector
            value={currency}
            onChange={(curr) => onFieldChange('currency', curr)}
          />
        </div>
      </Card>
    </div>
  );
}