import { useState, useEffect } from "react";
import { Plus, Users, Phone, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import type { Client } from "@shared/schema";

interface ClientSectionProps {
  selectedClientId?: string;
  onClientSelect: (client: Client | null) => void;
}

// todo: remove mock functionality - replace with real client management
const mockClients: Client[] = [
  {
    id: "1",
    name: "Tech Solutions Inc",
    phone: "+1 (555) 123-4567",
    email: "contact@techsolutions.com",
    address: "123 Business Ave, Suite 100\nSan Francisco, CA 94105"
  },
  {
    id: "2", 
    name: "Digital Marketing Pro",
    phone: "+1 (555) 987-6543",
    email: "info@digitalmarketingpro.com",
    address: "456 Marketing St\nNew York, NY 10001"
  }
];

export default function ClientSection({ selectedClientId, onClientSelect }: ClientSectionProps) {
  const [clients, setClients] = useState<Client[]>(mockClients);
  const [isAddingClient, setIsAddingClient] = useState(false);
  const [newClient, setNewClient] = useState<Partial<Client>>({
    name: '',
    phone: '',
    email: '',
    address: ''
  });

  const selectedClient = clients.find(c => c.id === selectedClientId);

  const handleAddClient = () => {
    if (newClient.name) {
      const client: Client = {
        id: Date.now().toString(),
        name: newClient.name,
        phone: newClient.phone || null,
        email: newClient.email || null,
        address: newClient.address || null
      };
      setClients([...clients, client]);
      onClientSelect(client);
      setNewClient({ name: '', phone: '', email: '', address: '' });
      setIsAddingClient(false);
      console.log('Added new client:', client.name);
    }
  };

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Users className="h-5 w-5 text-primary" />
          <h3 className="font-semibold">Client Information</h3>
        </div>
        
        <Dialog open={isAddingClient} onOpenChange={setIsAddingClient}>
          <DialogTrigger asChild>
            <Button size="sm" data-testid="button-add-client">
              <Plus className="h-4 w-4 mr-2" />
              Add Client
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Client</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="client-name">Client Name *</Label>
                <Input
                  id="client-name"
                  value={newClient.name}
                  onChange={(e) => setNewClient({...newClient, name: e.target.value})}
                  placeholder="Client or Company Name"
                  data-testid="input-new-client-name"
                />
              </div>
              <div>
                <Label htmlFor="client-phone">Phone Number</Label>
                <Input
                  id="client-phone"
                  value={newClient.phone || ''}
                  onChange={(e) => setNewClient({...newClient, phone: e.target.value})}
                  placeholder="+1 (555) 123-4567"
                  data-testid="input-new-client-phone"
                />
              </div>
              <div>
                <Label htmlFor="client-email">Email</Label>
                <Input
                  id="client-email"
                  type="email"
                  value={newClient.email || ''}
                  onChange={(e) => setNewClient({...newClient, email: e.target.value})}
                  placeholder="client@example.com"
                  data-testid="input-new-client-email"
                />
              </div>
              <div>
                <Label htmlFor="client-address">Address</Label>
                <Textarea
                  id="client-address"
                  value={newClient.address || ''}
                  onChange={(e) => setNewClient({...newClient, address: e.target.value})}
                  placeholder="Client Address"
                  className="min-h-[60px] resize-none"
                  data-testid="input-new-client-address"
                />
              </div>
              <div className="flex gap-2 pt-4">
                <Button onClick={handleAddClient} className="flex-1" data-testid="button-save-client">
                  Save Client
                </Button>
                <Button variant="outline" onClick={() => setIsAddingClient(false)} data-testid="button-cancel-client">
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-4">
        <div>
          <Label htmlFor="client-select">Select Client</Label>
          <Select 
            value={selectedClientId || ''} 
            onValueChange={(val) => {
              const client = clients.find(c => c.id === val);
              onClientSelect(client || null);
            }}
          >
            <SelectTrigger id="client-select" data-testid="select-client">
              <SelectValue placeholder="Choose a client..." />
            </SelectTrigger>
            <SelectContent>
              {clients.map((client) => (
                <SelectItem key={client.id} value={client.id} data-testid={`option-client-${client.id}`}>
                  {client.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {selectedClient && (
          <Card className="p-3 bg-primary/5 border-primary/20">
            <div className="space-y-2">
              <div className="font-medium text-primary" data-testid="text-selected-client-name">
                {selectedClient.name}
              </div>
              {selectedClient.phone && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Phone className="h-3 w-3" />
                  <span data-testid="text-selected-client-phone">{selectedClient.phone}</span>
                </div>
              )}
              {selectedClient.email && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Mail className="h-3 w-3" />
                  <span data-testid="text-selected-client-email">{selectedClient.email}</span>
                </div>
              )}
              {selectedClient.address && (
                <div className="text-sm text-muted-foreground whitespace-pre-line" data-testid="text-selected-client-address">
                  {selectedClient.address}
                </div>
              )}
            </div>
          </Card>
        )}
      </div>
    </Card>
  );
}