import { useState } from "react";
import { Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

interface LogoUploaderProps {
  logoUrl?: string;
  onLogoChange: (file: File | null) => void;
}

export default function LogoUploader({ logoUrl, onLogoChange }: LogoUploaderProps) {
  const [preview, setPreview] = useState<string | null>(logoUrl || null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
      onLogoChange(file);
    }
  };

  const handleRemove = () => {
    setPreview(null);
    onLogoChange(null);
  };

  return (
    <Card className="p-4">
      <div className="flex items-center gap-4">
        {preview ? (
          <div className="relative">
            <img 
              src={preview} 
              alt="Company Logo" 
              className="h-16 w-16 object-contain rounded-md border bg-white"
            />
            <Button
              size="icon"
              variant="destructive"
              className="absolute -top-2 -right-2 h-6 w-6"
              onClick={handleRemove}
              data-testid="button-remove-logo"
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
        ) : (
          <div className="h-16 w-16 border-2 border-dashed border-muted-foreground/25 rounded-md flex items-center justify-center bg-muted/30">
            <Upload className="h-6 w-6 text-muted-foreground" />
          </div>
        )}
        
        <div>
          <input
            type="file"
            id="logo-upload"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
            data-testid="input-logo-upload"
          />
          <label htmlFor="logo-upload">
            <Button variant="outline" asChild data-testid="button-upload-logo">
              <span>
                <Upload className="h-4 w-4 mr-2" />
                Upload Logo
              </span>
            </Button>
          </label>
          <p className="text-xs text-muted-foreground mt-1">
            PNG, JPG up to 2MB
          </p>
        </div>
      </div>
    </Card>
  );
}