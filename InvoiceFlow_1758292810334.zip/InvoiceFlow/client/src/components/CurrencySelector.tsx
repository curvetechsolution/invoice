import { currencies, type Currency } from "@shared/schema";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

interface CurrencySelectorProps {
  value: Currency;
  onChange: (currency: Currency) => void;
}

const currencySymbols: Record<Currency, string> = {
  PKR: "₨",
  USD: "$",
  EUR: "€",
  GBP: "£"
};

const currencyNames: Record<Currency, string> = {
  PKR: "Pakistani Rupee",
  USD: "US Dollar", 
  EUR: "Euro",
  GBP: "British Pound"
};

export default function CurrencySelector({ value, onChange }: CurrencySelectorProps) {
  return (
    <div className="space-y-2">
      <Label htmlFor="currency-select">Currency</Label>
      <Select value={value} onValueChange={(val) => onChange(val as Currency)}>
        <SelectTrigger id="currency-select" data-testid="select-currency">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {currencies.map((currency) => (
            <SelectItem key={currency} value={currency} data-testid={`option-currency-${currency}`}>
              <div className="flex items-center gap-2">
                <span className="font-medium">{currencySymbols[currency]}</span>
                <span>{currency}</span>
                <span className="text-sm text-muted-foreground">- {currencyNames[currency]}</span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}