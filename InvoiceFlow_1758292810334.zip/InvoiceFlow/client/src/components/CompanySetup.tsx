import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Building2, CheckCircle } from "lucide-react";
import LogoUploader from "./LogoUploader";
import { useToast } from "@/hooks/use-toast";
import logoImage from "@assets/generated_images/Professional_invoice_software_logo_b767a819.png";

interface CompanySetupProps {
  user: any;
  onSetupComplete: (companyData: any) => void;
}

export default function CompanySetup({ user, onSetupComplete }: CompanySetupProps) {
  const [companyData, setCompanyData] = useState({
    companyName: '',
    companyAddress: '',
    companyPhone: '',
    companyEmail: user.email,
    logoUrl: logoImage
  });
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleFieldChange = (field: string, value: any) => {
    setCompanyData(prev => ({
      ...prev,
      [field]: value
    }));
    console.log(`Company ${field} changed:`, value);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!companyData.companyName.trim()) {
      toast({
        title: "Error",
        description: "Company name is required",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    
    // todo: remove mock functionality - implement real company data saving
    console.log('Saving company data:', companyData);
    
    // Simulate API call
    setTimeout(() => {
      const updatedUser = {
        ...user,
        ...companyData,
        isSetupComplete: true
      };
      
      onSetupComplete(updatedUser);
      toast({
        title: "Setup Complete",
        description: "Your company profile has been saved successfully!"
      });
      
      setIsLoading(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-primary/10 p-3 rounded-full">
              <Building2 className="h-8 w-8 text-primary" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-primary mb-2">Company Setup</h1>
          <p className="text-muted-foreground">
            Welcome {user.firstName}! Let's set up your company profile for professional invoices.
          </p>
        </div>

        <Card className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Logo Upload */}
            <div>
              <Label className="text-base font-medium mb-4 block">Company Logo</Label>
              <LogoUploader 
                logoUrl={companyData.logoUrl}
                onLogoChange={(file) => handleFieldChange('logoUrl', file)}
              />
            </div>

            {/* Company Details */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="company-name" className="text-base">Company Name *</Label>
                <Input
                  id="company-name"
                  value={companyData.companyName}
                  onChange={(e) => handleFieldChange('companyName', e.target.value)}
                  placeholder="Your Company Name"
                  required
                  data-testid="input-setup-company-name"
                />
              </div>

              <div>
                <Label htmlFor="company-address" className="text-base">Company Address</Label>
                <Textarea
                  id="company-address"
                  value={companyData.companyAddress}
                  onChange={(e) => handleFieldChange('companyAddress', e.target.value)}
                  placeholder="Street Address&#10;City, State ZIP"
                  className="min-h-[80px] resize-none"
                  data-testid="input-setup-company-address"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="company-phone" className="text-base">Phone Number</Label>
                  <Input
                    id="company-phone"
                    value={companyData.companyPhone}
                    onChange={(e) => handleFieldChange('companyPhone', e.target.value)}
                    placeholder="+1 (555) 123-4567"
                    data-testid="input-setup-company-phone"
                  />
                </div>
                <div>
                  <Label htmlFor="company-email" className="text-base">Company Email</Label>
                  <Input
                    id="company-email"
                    type="email"
                    value={companyData.companyEmail}
                    onChange={(e) => handleFieldChange('companyEmail', e.target.value)}
                    placeholder="info@company.com"
                    data-testid="input-setup-company-email"
                  />
                </div>
              </div>
            </div>

            <div className="pt-4">
              <Button 
                type="submit" 
                className="w-full h-12 text-base"
                disabled={isLoading}
                data-testid="button-complete-setup"
              >
                {isLoading ? (
                  <>Setting up your company...</>
                ) : (
                  <>
                    <CheckCircle className="h-5 w-5 mr-2" />
                    Complete Setup & Start Creating Invoices
                  </>
                )}
              </Button>
            </div>
          </form>
        </Card>

        <div className="mt-6 p-4 bg-muted/30 rounded-lg text-center">
          <div className="text-sm text-muted-foreground">
            This information will appear on your professional invoices and can be edited anytime.
          </div>
        </div>
      </div>
    </div>
  );
}