import { useState } from "react";
import { Download, FileText, Package, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

interface ExportButtonsProps {
  invoiceData: any; // Will be properly typed when implementing backend
  invoiceNumber: string;
}

export default function ExportButtons({ invoiceData, invoiceNumber }: ExportButtonsProps) {
  const [isExporting, setIsExporting] = useState(false);
  const [isCreatingZip, setIsCreatingZip] = useState(false);
  const { toast } = useToast();

  const handlePDFExport = async () => {
    setIsExporting(true);
    // todo: remove mock functionality - implement real PDF generation
    console.log('Exporting PDF for invoice:', invoiceNumber);
    
    // Simulate PDF generation
    setTimeout(() => {
      toast({
        title: "PDF Generated",
        description: `Invoice ${invoiceNumber}.pdf has been downloaded.`,
      });
      setIsExporting(false);
    }, 2000);
  };

  const handleZipExport = async () => {
    setIsCreatingZip(true);
    // todo: remove mock functionality - implement real ZIP creation for Hostinger deployment
    console.log('Creating ZIP package for deployment');
    
    // Simulate ZIP creation
    setTimeout(() => {
      toast({
        title: "ZIP Package Created",
        description: "Your invoice software is ready for Hostinger deployment.",
      });
      setIsCreatingZip(false);
    }, 3000);
  };

  const handleShareLink = () => {
    // todo: remove mock functionality - implement real link sharing
    const mockLink = `https://your-domain.com/invoice/${invoiceNumber}`;
    navigator.clipboard.writeText(mockLink);
    console.log('Shared invoice link:', mockLink);
    
    toast({
      title: "Link Copied",
      description: "Invoice sharing link copied to clipboard.",
    });
  };

  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 mb-4">
        <Download className="h-5 w-5 text-primary" />
        <h3 className="font-semibold">Export & Share</h3>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        <Button 
          onClick={handlePDFExport}
          disabled={isExporting}
          className="flex items-center justify-center gap-2"
          data-testid="button-export-pdf"
        >
          <FileText className="h-4 w-4" />
          {isExporting ? 'Generating...' : 'Export PDF'}
        </Button>
        
        <Button 
          variant="outline"
          onClick={handleShareLink}
          className="flex items-center justify-center gap-2"
          data-testid="button-share-link"
        >
          <Share2 className="h-4 w-4" />
          Share Link
        </Button>
        
        <Button 
          variant="secondary"
          onClick={handleZipExport}
          disabled={isCreatingZip}
          className="flex items-center justify-center gap-2 md:col-span-2"
          data-testid="button-export-zip"
        >
          <Package className="h-4 w-4" />
          {isCreatingZip ? 'Creating ZIP...' : 'Download ZIP for Hostinger'}
        </Button>
      </div>
      
      <div className="mt-4 p-3 bg-primary/5 border border-primary/20 rounded-lg">
        <div className="text-sm">
          <div className="font-medium text-primary mb-1">Ready for Deployment</div>
          <div className="text-muted-foreground text-xs">
            The ZIP export contains all necessary files to upload directly to your Hostinger hosting account.
          </div>
        </div>
      </div>
    </Card>
  );
}