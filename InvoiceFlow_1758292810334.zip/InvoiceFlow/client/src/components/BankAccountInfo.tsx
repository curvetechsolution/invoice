import { useState } from "react";
import { CreditCard, Building, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

interface BankAccountInfoProps {
  bankDetails: {
    accountName: string;
    bankName: string;
    accountNumber: string;
    routingNumber: string;
    swiftCode: string;
    paypalEmail: string;
    enablePayPal: boolean;
  };
  onBankDetailsChange: (field: string, value: string | boolean) => void;
}

export default function BankAccountInfo({ bankDetails, onBankDetailsChange }: BankAccountInfoProps) {
  const [showAdvanced, setShowAdvanced] = useState(false);

  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 mb-4">
        <Building className="h-5 w-5 text-primary" />
        <h3 className="font-semibold">Payment Account Information</h3>
      </div>
      
      <div className="space-y-4">
        {/* Bank Account Details */}
        <div className="space-y-3">
          <div>
            <Label htmlFor="account-name">Account Holder Name</Label>
            <Input
              id="account-name"
              value={bankDetails.accountName}
              onChange={(e) => onBankDetailsChange('accountName', e.target.value)}
              placeholder="Business Account Holder"
              data-testid="input-account-name"
            />
          </div>
          
          <div>
            <Label htmlFor="bank-name">Bank Name</Label>
            <Input
              id="bank-name"
              value={bankDetails.bankName}
              onChange={(e) => onBankDetailsChange('bankName', e.target.value)}
              placeholder="Bank of America"
              data-testid="input-bank-name"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <Label htmlFor="account-number">Account Number</Label>
              <Input
                id="account-number"
                value={bankDetails.accountNumber}
                onChange={(e) => onBankDetailsChange('accountNumber', e.target.value)}
                placeholder="1234567890"
                data-testid="input-account-number"
              />
            </div>
            <div>
              <Label htmlFor="routing-number">Routing Number</Label>
              <Input
                id="routing-number"
                value={bankDetails.routingNumber}
                onChange={(e) => onBankDetailsChange('routingNumber', e.target.value)}
                placeholder="021000021"
                data-testid="input-routing-number"
              />
            </div>
          </div>
          
          {/* Advanced Options */}
          <div className="flex items-center justify-between pt-2">
            <Label>Show Advanced Options</Label>
            <Switch
              checked={showAdvanced}
              onCheckedChange={setShowAdvanced}
              data-testid="switch-advanced-options"
            />
          </div>
          
          {showAdvanced && (
            <div>
              <Label htmlFor="swift-code">SWIFT/BIC Code (International)</Label>
              <Input
                id="swift-code"
                value={bankDetails.swiftCode}
                onChange={(e) => onBankDetailsChange('swiftCode', e.target.value)}
                placeholder="CHASUS33"
                data-testid="input-swift-code"
              />
            </div>
          )}
        </div>

        {/* PayPal Integration */}
        <div className="border-t pt-4 mt-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <CreditCard className="h-4 w-4 text-blue-600" />
              <Label>Enable PayPal Integration</Label>
            </div>
            <Switch
              checked={bankDetails.enablePayPal}
              onCheckedChange={(checked) => onBankDetailsChange('enablePayPal', checked)}
              data-testid="switch-paypal"
            />
          </div>
          
          {bankDetails.enablePayPal && (
            <div>
              <Label htmlFor="paypal-email">PayPal Business Email</Label>
              <Input
                id="paypal-email"
                type="email"
                value={bankDetails.paypalEmail}
                onChange={(e) => onBankDetailsChange('paypalEmail', e.target.value)}
                placeholder="business@company.com"
                data-testid="input-paypal-email"
              />
              <p className="text-xs text-muted-foreground mt-1">
                This will add a PayPal payment link to your invoices
              </p>
            </div>
          )}
        </div>

        {/* Payment Instructions Preview */}
        <div className="bg-muted/30 p-3 rounded-lg mt-4">
          <div className="text-sm">
            <div className="font-medium mb-2">Payment Instructions Preview:</div>
            <div className="text-xs text-muted-foreground space-y-1">
              {bankDetails.accountName && (
                <div>Account: {bankDetails.accountName}</div>
              )}
              {bankDetails.bankName && (
                <div>Bank: {bankDetails.bankName}</div>
              )}
              {bankDetails.accountNumber && (
                <div>Account #: ****{bankDetails.accountNumber.slice(-4)}</div>
              )}
              {bankDetails.enablePayPal && bankDetails.paypalEmail && (
                <div>PayPal: {bankDetails.paypalEmail}</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}