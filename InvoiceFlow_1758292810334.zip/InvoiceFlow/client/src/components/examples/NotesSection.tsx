import { useState } from 'react'
import NotesSection from '../NotesSection'

export default function NotesSectionExample() {
  const [notes, setNotes] = useState('')

  return (
    <NotesSection 
      notes={notes}
      onNotesChange={(newNotes) => {
        setNotes(newNotes)
        console.log('Notes changed:', newNotes.length, 'characters')
      }}
    />
  )
}