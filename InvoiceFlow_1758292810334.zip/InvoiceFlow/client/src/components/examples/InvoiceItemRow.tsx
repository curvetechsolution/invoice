import InvoiceItemRow from '../InvoiceItemRow'
import type { InvoiceItem } from '@shared/schema'

export default function InvoiceItemRowExample() {
  const sampleItem: InvoiceItem = {
    id: '1',
    invoiceId: 'invoice-123',
    title: 'Website Development',
    description: 'Custom WordPress website with responsive design',
    unitPrice: '1500.00',
    quantity: 1,
    discountType: 'percentage',
    discountValue: '10.00'
  }

  return (
    <InvoiceItemRow 
      item={sampleItem}
      currency="USD"
      onUpdate={(id, field, value) => console.log(`Item ${id} - ${field}:`, value)}
      onDelete={(id) => console.log('Delete item:', id)}
    />
  )
}