import { useState } from 'react'
import ClientSection from '../ClientSection'
import type { Client } from '@shared/schema'

export default function ClientSectionExample() {
  const [selectedClient, setSelectedClient] = useState<Client | null>(null)

  return (
    <ClientSection 
      selectedClientId={selectedClient?.id}
      onClientSelect={(client) => {
        setSelectedClient(client)
        console.log('Selected client:', client?.name || 'none')
      }}
    />
  )
}