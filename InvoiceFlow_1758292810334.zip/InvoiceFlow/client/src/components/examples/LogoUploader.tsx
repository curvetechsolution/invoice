import LogoUploader from '../LogoUploader'

export default function LogoUploaderExample() {
  return (
    <LogoUploader 
      onLogoChange={(file) => console.log('Logo changed:', file?.name || 'removed')} 
    />
  )
}