import { useState } from 'react'
import InvoiceHeader from '../InvoiceHeader'
import type { Currency } from '@shared/schema'

export default function InvoiceHeaderExample() {
  const [headerData, setHeaderData] = useState({
    invoiceNumber: 'INV-001',
    issueDate: '2024-01-15',
    dueDate: '2024-02-15',
    currency: 'USD' as Currency,
    companyName: 'Your Company Name',
    companyAddress: '123 Business Street\nSuite 100\nCity, State 12345',
    companyPhone: '+1 (555) 123-4567',
    companyEmail: 'info@yourcompany.com',
  })

  const handleFieldChange = (field: string, value: any) => {
    setHeaderData(prev => ({ ...prev, [field]: value }))
    console.log(`${field} changed:`, value)
  }

  return (
    <InvoiceHeader 
      {...headerData}
      onFieldChange={handleFieldChange}
    />
  )
}