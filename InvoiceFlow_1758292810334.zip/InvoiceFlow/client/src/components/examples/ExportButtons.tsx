import ExportButtons from '../ExportButtons'

export default function ExportButtonsExample() {
  const sampleInvoiceData = {
    invoiceNumber: 'INV-001',
    total: 2750.00,
    currency: 'USD',
    clientName: 'Tech Solutions Inc'
  }

  return (
    <ExportButtons 
      invoiceData={sampleInvoiceData}
      invoiceNumber="INV-001"
    />
  )
}