import { useState } from 'react'
import InvoiceTotal from '../InvoiceTotal'

export default function InvoiceTotalExample() {
  const [depositPercentage, setDepositPercentage] = useState(50)
  const [isPaid, setIsPaid] = useState(false)

  return (
    <InvoiceTotal 
      currency="USD"
      subtotal={2750.00}
      depositPercentage={depositPercentage}
      isPaid={isPaid}
      onDepositChange={(percentage) => {
        setDepositPercentage(percentage)
        console.log('Deposit percentage changed:', percentage)
      }}
      onPaymentStatusToggle={() => {
        setIsPaid(!isPaid)
        console.log('Payment status toggled:', !isPaid)
      }}
    />
  )
}