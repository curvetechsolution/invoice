import { useState } from 'react'
import CurrencySelector from '../CurrencySelector'
import type { Currency } from '@shared/schema'

export default function CurrencySelectorExample() {
  const [currency, setCurrency] = useState<Currency>('USD')
  
  return (
    <CurrencySelector 
      value={currency} 
      onChange={(curr) => {
        setCurrency(curr)
        console.log('Currency changed to:', curr)
      }} 
    />
  )
}